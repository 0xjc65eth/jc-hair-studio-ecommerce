import Image from 'next/image';
import Link from 'next/link';
import { Metadata } from 'next';
import { Star, CheckCircle, ShoppingCart, Palette, Eye, Droplet, Brush } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Maquiagem - Produtos de Beleza Premium',
  description: 'Produtos de maquiagem premium para rosto, olhos e lábios. Bases, corretivos, paletas, batons e acessórios para uma beleza completa.',
  keywords: ['maquiagem', 'base', 'batom', 'paleta', 'corretivo', 'pó', 'primer', 'máscara', 'delineador', 'gloss'],
  openGraph: {
    title: 'Maquiagem - JC Hair Studio\'s 62',
    description: 'Produtos de maquiagem premium para realçar sua beleza natural',
    images: ['/og-maquiagem.jpg'],
  },
};

const makeupCategories = [
  {
    id: 'rosto',
    name: 'Rosto',
    icon: <Palette className="w-6 h-6" />,
    description: 'Base perfeita para sua pele',
    subcategories: ['Bases', 'Corretivos', 'Pós Compactos', 'Primers'],
    color: 'from-pink-100 to-rose-100',
    borderColor: 'border-pink-200',
    textColor: 'text-pink-600',
    products: [
      {
        id: '1',
        name: 'Base Líquida Ultra Cobertura',
        price: 45.90,
        comparePrice: 55.90,
        brand: 'Perfect Skin',
        rating: 4.8,
        reviews: 234,
        image: '/makeup/base-liquida.jpg'
      },
      {
        id: '2',
        name: 'Corretivo Full Coverage',
        price: 28.90,
        comparePrice: 35.90,
        brand: 'ConcealPro',
        rating: 4.7,
        reviews: 189,
        image: '/makeup/corretivo.jpg'
      },
      {
        id: '3',
        name: 'Pó Compacto Matte Finish',
        price: 32.50,
        comparePrice: null,
        brand: 'MattePro',
        rating: 4.6,
        reviews: 156,
        image: '/makeup/po-compacto.jpg'
      }
    ]
  },
  {
    id: 'olhos',
    name: 'Olhos',
    icon: <Eye className="w-6 h-6" />,
    description: 'Olhar marcante e expressivo',
    subcategories: ['Paletas de Sombra', 'Máscaras para Cílios', 'Delineadores', 'Lápis de Olho'],
    color: 'from-purple-100 to-indigo-100',
    borderColor: 'border-purple-200',
    textColor: 'text-purple-600',
    products: [
      {
        id: '4',
        name: 'Paleta de Sombras Nude',
        price: 58.90,
        comparePrice: 68.90,
        brand: 'EyeArt',
        rating: 4.9,
        reviews: 298,
        image: '/makeup/paleta-sombras.jpg'
      },
      {
        id: '5',
        name: 'Máscara para Cílios Volume',
        price: 38.90,
        comparePrice: null,
        brand: 'LashPro',
        rating: 4.8,
        reviews: 203,
        image: '/makeup/mascara-cilios.jpg'
      },
      {
        id: '6',
        name: 'Delineador Líquido Preto',
        price: 24.90,
        comparePrice: 29.90,
        brand: 'LinePerfect',
        rating: 4.7,
        reviews: 167,
        image: '/makeup/delineador.jpg'
      }
    ]
  },
  {
    id: 'labios',
    name: 'Lábios',
    icon: <Droplet className="w-6 h-6" />,
    description: 'Cor e hidratação perfeitas',
    subcategories: ['Batons', 'Gloss Labial', 'Lápis de Boca', 'Hidratantes Labiais'],
    color: 'from-red-100 to-pink-100',
    borderColor: 'border-red-200',
    textColor: 'text-red-600',
    products: [
      {
        id: '7',
        name: 'Batom Matte Longa Duração',
        price: 35.90,
        comparePrice: 42.90,
        brand: 'LipMatte',
        rating: 4.8,
        reviews: 312,
        image: '/makeup/batom-matte.jpg'
      },
      {
        id: '8',
        name: 'Gloss Labial Hidratante',
        price: 22.90,
        comparePrice: null,
        brand: 'GlossyLips',
        rating: 4.6,
        reviews: 189,
        image: '/makeup/gloss.jpg'
      },
      {
        id: '9',
        name: 'Lápis de Boca Universal',
        price: 18.50,
        comparePrice: 22.50,
        brand: 'LipLine',
        rating: 4.5,
        reviews: 134,
        image: '/makeup/lapis-boca.jpg'
      }
    ]
  },
  {
    id: 'acessorios',
    name: 'Acessórios',
    icon: <Brush className="w-6 h-6" />,
    description: 'Ferramentas para aplicação perfeita',
    subcategories: ['Pincéis', 'Esponjas', 'Demaquilantes', 'Organizadores'],
    color: 'from-gray-100 to-gray-200',
    borderColor: 'border-gray-300',
    textColor: 'text-gray-600',
    products: [
      {
        id: '10',
        name: 'Kit Pincéis Profissionais',
        price: 89.90,
        comparePrice: 109.90,
        brand: 'BrushPro',
        rating: 4.9,
        reviews: 256,
        image: '/makeup/kit-pinceis.jpg'
      },
      {
        id: '11',
        name: 'Esponja de Maquiagem Beauty',
        price: 15.90,
        comparePrice: null,
        brand: 'BeautySponge',
        rating: 4.7,
        reviews: 189,
        image: '/makeup/esponja.jpg'
      },
      {
        id: '12',
        name: 'Água Micelar Demaquilante',
        price: 32.90,
        comparePrice: 38.90,
        brand: 'CleanSkin',
        rating: 4.8,
        reviews: 223,
        image: '/makeup/agua-micelar.jpg'
      }
    ]
  }
];

function CategoryCard({ category }: { category: typeof makeupCategories[0] }) {
  return (
    <div className={`bg-gradient-to-br ${category.color} rounded-xl p-6 border ${category.borderColor}`}>
      <div className="flex items-center mb-4">
        <div className={`p-3 bg-white rounded-lg ${category.textColor} mr-4`}>
          {category.icon}
        </div>
        <div>
          <h3 className="text-xl font-semibold text-gray-900">{category.name}</h3>
          <p className="text-sm text-gray-600">{category.description}</p>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-900 mb-3">Subcategorias:</h4>
        <div className="grid grid-cols-2 gap-2">
          {category.subcategories.map((sub, index) => (
            <div key={index} className="bg-white/70 px-3 py-2 rounded-lg text-sm text-gray-700">
              {sub}
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <h4 className="text-sm font-medium text-gray-900">Produtos em Destaque:</h4>
        {category.products.slice(0, 2).map((product) => (
          <div key={product.id} className="bg-white/80 p-3 rounded-lg">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h5 className="font-medium text-sm text-gray-900 mb-1">{product.name}</h5>
                <p className="text-xs text-gray-600 mb-1">{product.brand}</p>
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-semibold text-gray-900">€{product.price.toFixed(2)}</span>
                  {product.comparePrice && (
                    <span className="text-xs text-gray-500 line-through">€{product.comparePrice.toFixed(2)}</span>
                  )}
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center">
                  <Star className="w-3 h-3 text-yellow-400 fill-current" />
                  <span className="text-xs text-gray-600 ml-1">{product.rating}</span>
                </div>
                <span className="text-xs text-gray-500">({product.reviews})</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-white/50">
        <Link 
          href={`/maquiagem/${category.id}`}
          className={`block text-center py-3 px-4 bg-white ${category.textColor} rounded-lg font-medium hover:bg-gray-50 transition-colors`}
        >
          Ver Todos os Produtos de {category.name}
        </Link>
      </div>
    </div>
  );
}

export default function MakeupPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Realce sua <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600">Beleza</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
              Produtos de maquiagem premium para completar seu visual. 
              Do rosto aos lábios, tudo o que você precisa para brilhar.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
              <div className="bg-white/70 backdrop-blur-sm rounded-lg px-6 py-3 border border-pink-200">
                <div className="text-sm text-gray-600 mb-1">Produtos Premium</div>
                <div className="text-2xl font-bold text-gray-900">150+</div>
              </div>
              <div className="bg-white/70 backdrop-blur-sm rounded-lg px-6 py-3 border border-purple-200">
                <div className="text-sm text-gray-600 mb-1">Marcas Reconhecidas</div>
                <div className="text-2xl font-bold text-gray-900">25+</div>
              </div>
              <div className="bg-white/70 backdrop-blur-sm rounded-lg px-6 py-3 border border-rose-200">
                <div className="text-sm text-gray-600 mb-1">Satisfação</div>
                <div className="text-2xl font-bold text-gray-900">98%</div>
              </div>
            </div>

            <div className="flex justify-center space-x-4">
              <Link href="#categorias" className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-3 rounded-lg font-medium hover:from-pink-600 hover:to-purple-700 transition-all">
                Explorar Categorias
              </Link>
              <Link href="#novidades" className="bg-white text-gray-900 px-8 py-3 rounded-lg font-medium border border-gray-200 hover:bg-gray-50 transition-colors">
                Ver Novidades
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section id="categorias" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Explore por Categoria
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Encontre os produtos perfeitos para cada parte do seu rosto. 
              Qualidade premium e resultados profissionais.
            </p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {makeupCategories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Makeup Routine Guide */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Sua Rotina de Maquiagem Perfeita
            </h2>
            <p className="text-lg text-gray-600">
              Passo a passo para uma maquiagem impecável
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-pink-100 to-rose-100 rounded-full flex items-center justify-center">
                <span className="text-pink-600 font-bold text-lg">1</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Preparação da Pele</h3>
              <p className="text-sm text-gray-600">
                Primer para preparar e uniformizar a pele
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-full flex items-center justify-center">
                <span className="text-purple-600 font-bold text-lg">2</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Base e Correção</h3>
              <p className="text-sm text-gray-600">
                Base, corretivo e pó para o acabamento perfeito
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-bold text-lg">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Olhos Marcantes</h3>
              <p className="text-sm text-gray-600">
                Sombras, delineador e máscara para cílios
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center">
                <span className="text-red-600 font-bold text-lg">4</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Finalização</h3>
              <p className="text-sm text-gray-600">
                Batom, gloss e últimos retoques
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Our Makeup */}
      <section className="bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Por Que Escolher Nossos Produtos?
            </h2>
            <p className="text-lg text-gray-300">
              Qualidade premium que você pode confiar
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Longa Duração</h3>
              <p className="text-gray-300 text-sm">
                Fórmulas de alta performance que duram o dia todo sem retoques constantes
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center">
                <Palette className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Cores Vibrantes</h3>
              <p className="text-gray-300 text-sm">
                Pigmentação intensa e cores que se mantêm fiéis durante toda a aplicação
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center">
                <Star className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Resultados Profissionais</h3>
              <p className="text-gray-300 text-sm">
                Produtos desenvolvidos para proporcionar acabamento digno de salão de beleza
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-pink-50 to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Complete seu Kit de Maquiagem
          </h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Encontre todos os produtos que você precisa para criar looks incríveis. 
            Da maquiagem básica do dia a dia até produções mais elaboradas.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/produtos" className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-8 py-3 rounded-lg font-medium hover:from-pink-600 hover:to-purple-700 transition-all">
              Ver Produtos Capilares
            </Link>
            <Link href="#categorias" className="bg-white text-gray-900 px-8 py-3 rounded-lg font-medium border border-gray-200 hover:bg-gray-50 transition-colors">
              Explorar Maquiagem
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}