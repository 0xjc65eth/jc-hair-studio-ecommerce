'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';

// Dados profissionais do catálogo de mega hair
const megaHairCatalog = {
  collections: [
    {
      id: 'premium',
      name: 'Coleção Premium',
      description: 'Cabelos naturais 100% humanos, origem europeia e asiática selecionada',
      products: [
        {
          id: 'premium-loiro-platinado',
          name: 'Loiro Platinado Premium',
          length: '60cm',
          weight: '100g',
          type: 'Cabelo Humano Natural',
          origin: 'Europa',
          price: 1200,
          available: true,
          image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=400&h=500&fit=crop&auto=format',
          colors: ['#f5f5dc', '#f0e68c', '#fff8dc']
        },
        {
          id: 'premium-castanho-chocolate',
          name: 'Castanho Chocolate',
          length: '55cm',
          weight: '120g', 
          type: 'Cabelo Humano Natural',
          origin: 'Brasil',
          price: 980,
          available: true,
          image: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=500&fit=crop&auto=format',
          colors: ['#8b4513', '#a0522d', '#cd853f']
        },
        {
          id: 'premium-preto-natural',
          name: 'Preto Natural Intenso',
          length: '70cm',
          weight: '150g',
          type: 'Cabelo Humano Natural',
          origin: 'Ásia',
          price: 850,
          available: true,
          image: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=400&h=500&fit=crop&auto=format',
          colors: ['#000000', '#1c1c1c', '#2f2f2f']
        },
        {
          id: 'premium-ruivo-acobreado',
          name: 'Ruivo Acobreado',
          length: '50cm',
          weight: '80g',
          type: 'Cabelo Humano Natural',
          origin: 'Europa',
          price: 1400,
          available: false,
          image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=500&fit=crop&auto=format',
          colors: ['#b22222', '#cd5c5c', '#f4a460']
        }
      ]
    },
    {
      id: 'professional',
      name: 'Linha Profissional',
      description: 'Extensões de alta qualidade para uso profissional e comercial',
      products: [
        {
          id: 'prof-loiro-mel',
          name: 'Loiro Mel Profissional',
          length: '45cm',
          weight: '100g',
          type: 'Cabelo Sintético Premium',
          origin: 'Nacional',
          price: 420,
          available: true,
          image: 'https://images.unsplash.com/photo-1594736797933-d0cba2fe8421?w=400&h=500&fit=crop&auto=format',
          colors: ['#daa520', '#ffd700', '#f0e68c']
        },
        {
          id: 'prof-castanho-medio',
          name: 'Castanho Médio',
          length: '50cm',
          weight: '90g',
          type: 'Cabelo Sintético Premium',
          origin: 'Nacional',
          price: 380,
          available: true,
          image: 'https://images.unsplash.com/photo-1550939267-2372deb7b780?w=400&h=500&fit=crop&auto=format',
          colors: ['#8b4513', '#a0522d', '#d2691e']
        },
        {
          id: 'prof-ombre-hair',
          name: 'Ombré Hair Degradê',
          length: '55cm',
          weight: '110g',
          type: 'Cabelo Sintético Premium',
          origin: 'Nacional',
          price: 520,
          available: true,
          image: 'https://images.unsplash.com/photo-1526045431048-f857369baa09?w=400&h=500&fit=crop&auto=format',
          colors: ['#2f2f2f', '#8b4513', '#daa520']
        }
      ]
    },
    {
      id: 'basic',
      name: 'Linha Essencial',
      description: 'Opções acessíveis com qualidade garantida para uso pessoal',
      products: [
        {
          id: 'basic-preto-liso',
          name: 'Preto Liso Essencial',
          length: '40cm',
          weight: '70g',
          type: 'Fibra Sintética',
          origin: 'Nacional',
          price: 180,
          available: true,
          image: 'https://images.unsplash.com/photo-1556227834-09f1de7a7d14?w=400&h=500&fit=crop&auto=format',
          colors: ['#000000', '#1c1c1c']
        },
        {
          id: 'basic-castanho-claro',
          name: 'Castanho Claro',
          length: '35cm',
          weight: '60g',
          type: 'Fibra Sintética',
          origin: 'Nacional',
          price: 150,
          available: true,
          image: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?w=400&h=500&fit=crop&auto=format',
          colors: ['#d2691e', '#daa520', '#f4a460']
        }
      ]
    }
  ],
  unavailableColors: [
    { name: 'Loiro Acinzentado', hex: '#c0c0c0', availability: 'Disponível em breve' },
    { name: 'Ruivo Cereja', hex: '#dc143c', availability: 'Disponível em breve' },
    { name: 'Castanho Avermelhado', hex: '#a0522d', availability: 'Disponível em breve' },
    { name: 'Preto Azulado', hex: '#191970', availability: 'Disponível em breve' }
  ]
};

export default function MegaHairCatalog() {
  const [selectedCollection, setSelectedCollection] = useState('premium');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simula carregamento profissional
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const currentCollection = megaHairCatalog.collections.find(c => c.id === selectedCollection);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-rose-200 border-t-rose-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 font-light">Carregando catálogo profissional...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header Profissional */}
      <section className="bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center max-w-4xl mx-auto">
            <motion.h1 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl font-thin mb-4 tracking-wide"
            >
              Catálogo <span className="font-light text-rose-400">Mega Hair</span>
            </motion.h1>
            <div className="w-24 h-1 bg-gradient-to-r from-rose-400 to-rose-600 mx-auto mb-6 rounded-full"></div>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-gray-300 font-light leading-relaxed"
            >
              Extensões capilares de alta qualidade, selecionadas criteriosamente para 
              profissionais exigentes e clientes que buscam excelência.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Navigation Elegante */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-center space-x-8 py-6">
            {megaHairCatalog.collections.map((collection) => (
              <button
                key={collection.id}
                onClick={() => setSelectedCollection(collection.id)}
                className={`px-6 py-3 rounded-full text-sm font-medium tracking-wide transition-all duration-300 ${
                  selectedCollection === collection.id
                    ? 'bg-gray-900 text-white shadow-lg'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                {collection.name}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Collection Header */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <motion.h2 
            key={selectedCollection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-3xl font-light text-gray-900 mb-4"
          >
            {currentCollection?.name}
          </motion.h2>
          <motion.p 
            key={`desc-${selectedCollection}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-gray-600 max-w-2xl mx-auto font-light leading-relaxed"
          >
            {currentCollection?.description}
          </motion.p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div 
            key={selectedCollection}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {currentCollection?.products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group"
              >
                <div className="relative h-64 bg-gradient-to-br from-gray-100 to-gray-200">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-20 h-20 bg-gray-300 rounded-full mx-auto mb-3 flex items-center justify-center">
                        <span className="text-2xl">✨</span>
                      </div>
                      <p className="text-gray-500 text-sm">Imagem profissional</p>
                      <p className="text-gray-400 text-xs">em produção</p>
                    </div>
                  </div>
                  
                  {/* Status Badge */}
                  <div className="absolute top-4 right-4">
                    {product.available ? (
                      <span className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                        Disponível
                      </span>
                    ) : (
                      <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-medium">
                        Em breve
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-medium text-gray-900 mb-2 group-hover:text-rose-600 transition-colors">
                    {product.name}
                  </h3>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Comprimento:</span>
                      <span className="font-medium">{product.length}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Peso:</span>
                      <span className="font-medium">{product.weight}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Tipo:</span>
                      <span className="font-medium">{product.type}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Origem:</span>
                      <span className="font-medium">{product.origin}</span>
                    </div>
                  </div>

                  {/* Color Swatches */}
                  <div className="mb-4">
                    <p className="text-sm text-gray-600 mb-2">Tons disponíveis:</p>
                    <div className="flex space-x-2">
                      {product.colors.map((color, idx) => (
                        <div
                          key={idx}
                          className="w-6 h-6 rounded-full border-2 border-gray-300 shadow-sm"
                          style={{ backgroundColor: color }}
                          title={`Tom ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div>
                      <p className="text-2xl font-light text-gray-900">
                        {formatPrice(product.price)}
                      </p>
                      <p className="text-xs text-gray-500">à vista</p>
                    </div>
                    <button
                      onClick={() => setSelectedProduct(product)}
                      className="bg-gray-900 text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-gray-800 transition-colors"
                    >
                      Detalhes
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Cores em Breve */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-light text-gray-900 mb-4">
              Próximos Lançamentos
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto font-light">
              Novos tons exclusivos sendo desenvolvidos especialmente para nossos clientes.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {megaHairCatalog.unavailableColors.map((color, index) => (
              <motion.div
                key={color.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="text-center p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <div
                  className="w-16 h-16 rounded-full mx-auto mb-4 border-4 border-white shadow-lg"
                  style={{ backgroundColor: color.hex }}
                />
                <h3 className="font-medium text-gray-900 mb-1">{color.name}</h3>
                <p className="text-sm text-orange-600 font-medium">{color.availability}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Professional Contact */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-light mb-6">Atendimento Profissional</h2>
          <p className="text-gray-300 font-light mb-8 leading-relaxed">
            Nossa equipe especializada está pronta para orientar você na escolha perfeita 
            do mega hair ideal para cada cliente e ocasião.
          </p>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-rose-600 rounded-full flex items-center justify-center">
                <span className="text-xl">📱</span>
              </div>
              <div className="text-left">
                <p className="font-medium">WhatsApp</p>
                <p className="text-gray-400 text-sm">(11) 99999-9999</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-rose-600 rounded-full flex items-center justify-center">
                <span className="text-xl">📧</span>
              </div>
              <div className="text-left">
                <p className="font-medium">E-mail</p>
                <p className="text-gray-400 text-sm">contato@jchairstudio.com</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Modal de Produto */}
      <AnimatePresence>
        {selectedProduct && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedProduct(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <h2 className="text-2xl font-light text-gray-900">
                    {selectedProduct.name}
                  </h2>
                  <button
                    onClick={() => setSelectedProduct(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  <div className="h-64 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-gray-300 rounded-full mx-auto mb-2 flex items-center justify-center">
                        <span className="text-2xl">✨</span>
                      </div>
                      <p className="text-gray-500 text-sm">Imagem em alta resolução</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Especificações Técnicas</h3>
                      <div className="space-y-2 text-sm text-gray-600">
                        <div className="flex justify-between">
                          <span>Comprimento:</span>
                          <span className="font-medium">{selectedProduct.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Peso:</span>
                          <span className="font-medium">{selectedProduct.weight}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Material:</span>
                          <span className="font-medium">{selectedProduct.type}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Procedência:</span>
                          <span className="font-medium">{selectedProduct.origin}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Tons Disponíveis</h3>
                      <div className="flex space-x-2">
                        {selectedProduct.colors.map((color: string, idx: number) => (
                          <div
                            key={idx}
                            className="w-8 h-8 rounded-full border-2 border-gray-300 shadow-sm"
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-100">
                      <p className="text-3xl font-light text-gray-900 mb-2">
                        {formatPrice(selectedProduct.price)}
                      </p>
                      <p className="text-sm text-gray-500 mb-4">Pagamento à vista</p>
                      
                      <button className="w-full bg-gray-900 text-white py-3 rounded-lg font-medium hover:bg-gray-800 transition-colors">
                        Solicitar Orçamento
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}