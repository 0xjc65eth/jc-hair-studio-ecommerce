// Authentication login endpoint for JC Hair Studio's 62 E-commerce
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { comparePassword, generateTokens } from '../../../../lib/auth/jwt';
import { withRateLimit, withValidation, withSecurityHeaders } from '../../../../lib/auth/middleware';
import { z } from 'zod';

const prisma = new PrismaClient();

// Validation schema
const loginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  rememberMe: z.boolean().optional().default(false),
});

type LoginData = z.infer<typeof loginSchema>;

async function loginHandler(request: NextRequest, validatedData: LoginData) {
  try {
    const { email, password, rememberMe } = validatedData;

    // Find user by email
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      select: {
        id: true,
        email: true,
        password: true,
        name: true,
        firstName: true,
        lastName: true,
        role: true,
        isActive: true,
        isVerified: true,
        lastLoginAt: true,
      }
    });

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid email or password',
          code: 'INVALID_CREDENTIALS'
        },
        { status: 401 }
      );
    }

    // Check if user is active
    if (!user.isActive) {
      return NextResponse.json(
        {
          success: false,
          error: 'Account is deactivated',
          code: 'ACCOUNT_DEACTIVATED'
        },
        { status: 401 }
      );
    }

    // Check if password exists (for OAuth users)
    if (!user.password) {
      return NextResponse.json(
        {
          success: false,
          error: 'Please use OAuth login or reset your password',
          code: 'NO_PASSWORD_SET'
        },
        { status: 401 }
      );
    }

    // Verify password
    const isValidPassword = await comparePassword(password, user.password);
    if (!isValidPassword) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid email or password',
          code: 'INVALID_CREDENTIALS'
        },
        { status: 401 }
      );
    }

    // Check if email is verified (optional - can be configured)
    const requireEmailVerification = process.env.REQUIRE_EMAIL_VERIFICATION === 'true';
    if (requireEmailVerification && !user.isVerified) {
      return NextResponse.json(
        {
          success: false,
          error: 'Please verify your email address',
          code: 'EMAIL_NOT_VERIFIED',
          data: {
            userId: user.id,
            email: user.email
          }
        },
        { status: 401 }
      );
    }

    // Determine user type based on business logic
    // This could be expanded with additional fields in the database
    const userType = user.role === 'CUSTOMER' ? 'RETAIL' : undefined;

    // Generate JWT tokens
    const tokens = generateTokens({
      userId: user.id,
      email: user.email,
      role: user.role,
      userType
    });

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() }
    });

    // Prepare user data for response (exclude sensitive info)
    const userData = {
      id: user.id,
      email: user.email,
      name: user.name || `${user.firstName || ''} ${user.lastName || ''}`.trim(),
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      userType,
      isVerified: user.isVerified,
      lastLoginAt: user.lastLoginAt
    };

    const response = NextResponse.json({
      success: true,
      message: 'Login successful',
      data: {
        user: userData,
        ...tokens
      }
    });

    // Set HTTP-only cookies for additional security
    if (rememberMe) {
      response.cookies.set('auth-token', tokens.accessToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 60 * 60 * 24 * 7 // 7 days
      });

      response.cookies.set('refresh-token', tokens.refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 60 * 60 * 24 * 30 // 30 days
      });
    }

    return response;

  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        code: 'SERVER_ERROR'
      },
      { status: 500 }
    );
  }
}

// Apply middleware
const POST = withSecurityHeaders(
  withRateLimit(
    withValidation(loginHandler, (data) => {
      try {
        const parsed = loginSchema.parse(data);
        return { success: true, data: parsed };
      } catch (error) {
        return { success: false, errors: error };
      }
    }),
    {
      maxRequests: 5,
      windowMs: 15 * 60 * 1000, // 15 minutes
      keyGenerator: (req) => {
        const forwarded = req.headers.get('x-forwarded-for');
        const ip = forwarded?.split(',')[0] || req.ip || 'anonymous';
        return `login:${ip}`;
      }
    }
  )
);

export { POST };