// Token refresh endpoint for JC Hair Studio's 62 E-commerce
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { verifyRefreshToken, generateTokens } from '../../../../lib/auth/jwt';
import { withRateLimit, withValidation, withSecurityHeaders } from '../../../../lib/auth/middleware';
import { z } from 'zod';

const prisma = new PrismaClient();

// Validation schema
const refreshSchema = z.object({
  refreshToken: z.string().min(1, 'Refresh token is required'),
});

type RefreshData = z.infer<typeof refreshSchema>;

async function refreshHandler(request: NextRequest, validatedData: RefreshData) {
  try {
    const { refreshToken } = validatedData;

    // Verify refresh token
    const payload = verifyRefreshToken(refreshToken);
    if (!payload) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid or expired refresh token',
          code: 'INVALID_REFRESH_TOKEN'
        },
        { status: 401 }
      );
    }

    // Get user data
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: {
        id: true,
        email: true,
        role: true,
        isActive: true,
        isVerified: true,
      }
    });

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          error: 'User not found',
          code: 'USER_NOT_FOUND'
        },
        { status: 401 }
      );
    }

    if (!user.isActive) {
      return NextResponse.json(
        {
          success: false,
          error: 'Account is deactivated',
          code: 'ACCOUNT_DEACTIVATED'
        },
        { status: 401 }
      );
    }

    // Determine user type (can be expanded with additional logic)
    const userType = user.role === 'CUSTOMER' ? 'RETAIL' : undefined;

    // Generate new tokens
    const tokens = generateTokens({
      userId: user.id,
      email: user.email,
      role: user.role,
      userType
    });

    const response = NextResponse.json({
      success: true,
      message: 'Tokens refreshed successfully',
      data: {
        ...tokens
      }
    });

    // Update HTTP-only cookies
    response.cookies.set('auth-token', tokens.accessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 // 1 day
    });

    response.cookies.set('refresh-token', tokens.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 60 * 60 * 24 * 7 // 7 days
    });

    return response;

  } catch (error) {
    console.error('Token refresh error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        code: 'SERVER_ERROR'
      },
      { status: 500 }
    );
  }
}

// Apply middleware
const POST = withSecurityHeaders(
  withRateLimit(
    withValidation(refreshHandler, (data) => {
      try {
        const parsed = refreshSchema.parse(data);
        return { success: true, data: parsed };
      } catch (error) {
        return { success: false, errors: error };
      }
    }),
    {
      maxRequests: 10,
      windowMs: 15 * 60 * 1000, // 15 minutes
      keyGenerator: (req) => {
        const forwarded = req.headers.get('x-forwarded-for');
        const ip = forwarded?.split(',')[0] || req.ip || 'anonymous';
        return `refresh:${ip}`;
      }
    }
  )
);

export { POST };