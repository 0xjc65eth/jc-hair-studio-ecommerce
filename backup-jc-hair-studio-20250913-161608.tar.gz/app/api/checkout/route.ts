import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/mongodb';

// Validation schemas
const AddressSchema = z.object({
  firstName: z.string().min(2, 'Primeiro nome deve ter pelo menos 2 caracteres').max(50),
  lastName: z.string().min(2, 'Último nome deve ter pelo menos 2 caracteres').max(50),
  company: z.string().max(100).optional(),
  street1: z.string().min(5, 'Endereço deve ter pelo menos 5 caracteres').max(200),
  street2: z.string().max(200).optional(),
  city: z.string().min(2, 'Cidade deve ter pelo menos 2 caracteres').max(100),
  state: z.string().max(50).optional(),
  postalCode: z.string().min(4, 'Código postal inválido').max(20),
  country: z.string().length(2, 'Código de país deve ter 2 caracteres').default('PT'),
  phone: z.string().min(9, 'Telefone inválido').max(20).optional(),
});

const CheckoutSchema = z.object({
  // Customer info
  email: z.string().email('Email inválido'),
  phone: z.string().min(9, 'Telefone inválido').max(20).optional(),
  
  // Addresses
  shippingAddress: AddressSchema,
  billingAddress: AddressSchema.optional(),
  sameAsBilling: z.boolean().default(false),
  
  // Cart info
  cartItems: z.array(z.object({
    productId: z.string(),
    variantId: z.string().optional(),
    quantity: z.number().int().min(1),
    selectedOptions: z.record(z.any()).optional(),
  })).min(1, 'Carrinho não pode estar vazio'),
  
  // Shipping & Payment
  shippingMethod: z.string().default('standard'),
  paymentMethod: z.enum(['CREDIT_CARD', 'DEBIT_CARD', 'PAYPAL', 'MULTIBANCO', 'SEPA']),
  
  // Customer type
  isGuest: z.boolean().default(true),
  userId: z.string().optional(),
  sessionId: z.string().optional(),
  
  // Marketing
  subscribeNewsletter: z.boolean().default(false),
  marketingConsent: z.boolean().default(false),
  
  // Discounts
  couponCode: z.string().optional(),
  
  // Notes
  orderNotes: z.string().max(500).optional(),
  
  // Terms
  agreedToTerms: z.boolean().refine(val => val === true, 'Deve aceitar os termos e condições'),
  agreedToPrivacy: z.boolean().refine(val => val === true, 'Deve aceitar a política de privacidade'),
});

// European VAT rates by country
const VAT_RATES: Record<string, number> = {
  'PT': 0.23, // Portugal - 23%
  'ES': 0.21, // Spain - 21%
  'FR': 0.20, // France - 20%
  'DE': 0.19, // Germany - 19%
  'IT': 0.22, // Italy - 22%
  'NL': 0.21, // Netherlands - 21%
  'BE': 0.21, // Belgium - 21%
  'AT': 0.20, // Austria - 20%
  'IE': 0.23, // Ireland - 23%
  'LU': 0.17, // Luxembourg - 17%
  'DEFAULT': 0.21, // Default EU VAT rate
};

// Shipping costs by method and country
const SHIPPING_COSTS = {
  standard: {
    domestic: 4.99, // Portugal
    eu: 9.99,      // Other EU countries
    international: 19.99,
    freeThreshold: 75, // Free shipping over 75€
  },
  express: {
    domestic: 9.99,
    eu: 19.99,
    international: 39.99,
    freeThreshold: 150, // Free express over 150€
  }
};

// Helper functions
function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `JC${timestamp.toUpperCase()}${random.toUpperCase()}`;
}

function calculateVAT(subtotal: number, countryCode: string): number {
  const vatRate = VAT_RATES[countryCode] || VAT_RATES.DEFAULT;
  return subtotal * vatRate;
}

function calculateShippingCost(subtotal: number, method: string, countryCode: string): number {
  const isEU = ['PT', 'ES', 'FR', 'DE', 'IT', 'NL', 'BE', 'AT', 'IE', 'LU'].includes(countryCode);
  const isDomestic = countryCode === 'PT';
  
  const shippingConfig = SHIPPING_COSTS[method as keyof typeof SHIPPING_COSTS] || SHIPPING_COSTS.standard;
  
  // Check for free shipping
  if (subtotal >= shippingConfig.freeThreshold) {
    return 0;
  }
  
  if (isDomestic) {
    return shippingConfig.domestic;
  } else if (isEU) {
    return shippingConfig.eu;
  } else {
    return shippingConfig.international;
  }
}

async function validateCartItems(cartItems: any[]): Promise<{valid: boolean, items?: any[], total?: number, error?: string}> {
  try {
    const validatedItems = [];
    let subtotal = 0;

    for (const item of cartItems) {
      // Get product data
      const product = await prisma.product.findFirst({
        where: {
          id: item.productId,
          status: 'ACTIVE'
        }
      });

      if (!product) {
        return {
          valid: false,
          error: `Produto ${item.productId} não encontrado ou não disponível`
        };
      }

      // Check stock
      if (product.trackQuantity && item.quantity > product.quantity) {
        return {
          valid: false,
          error: `Produto "${product.name}" não tem stock suficiente. Disponível: ${product.quantity}, solicitado: ${item.quantity}`
        };
      }

      // Get effective price
      const effectivePrice = product.isOnPromotion && product.promoPrice ? 
        product.promoPrice : product.price;

      const itemTotal = effectivePrice * item.quantity;
      subtotal += itemTotal;

      validatedItems.push({
        id: `item_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
        productId: item.productId,
        variantId: item.variantId || null,
        name: product.name,
        sku: product.sku,
        price: effectivePrice,
        quantity: item.quantity,
        selectedOptions: item.selectedOptions || null,
      });
    }

    return {
      valid: true,
      items: validatedItems,
      total: subtotal
    };

  } catch (error) {
    console.error('Error validating cart items:', error);
    return {
      valid: false,
      error: 'Erro ao validar itens do carrinho'
    };
  }
}

// Mock checkout response for fallback
const mockOrderResponse = {
  id: 'mock_order_123',
  orderNumber: 'JC123ABC456DEF',
  status: 'PENDING',
  paymentStatus: 'PENDING',
  total: 275.97,
  currency: 'EUR',
  items: [
    {
      id: 'item_1',
      productId: 'mock_1',
      name: 'Extensões Brasileiras Premium - 60cm',
      sku: 'EXT-BR-60-BLK',
      price: 129.99,
      quantity: 2,
      selectedOptions: {
        cor: 'Preto Natural',
        comprimento: '60cm'
      }
    }
  ],
  customer: {
    email: 'customer@example.com',
    phone: '+351912345678',
  },
  shippingAddress: {
    firstName: 'Maria',
    lastName: 'Silva',
    street1: 'Rua Example, 123',
    city: 'Porto',
    postalCode: '4000-000',
    country: 'PT',
  },
  pricing: {
    subtotal: 259.98,
    vatAmount: 59.80,
    shippingCost: 0,
    discountAmount: 0,
    total: 275.97,
  },
  createdAt: new Date(),
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate request body
    const validatedData = CheckoutSchema.parse(body);

    try {
      // Validate cart items and calculate totals
      const cartValidation = await validateCartItems(validatedData.cartItems);
      
      if (!cartValidation.valid) {
        return NextResponse.json(
          {
            success: false,
            message: 'Erro na validação do carrinho',
            error: cartValidation.error,
          },
          { status: 400 }
        );
      }

      const orderItems = cartValidation.items!;
      const subtotal = cartValidation.total!;

      // Calculate pricing
      const shippingAddress = validatedData.shippingAddress;
      const vatAmount = calculateVAT(subtotal, shippingAddress.country);
      const shippingCost = calculateShippingCost(subtotal, validatedData.shippingMethod, shippingAddress.country);
      
      // Apply discount if coupon provided
      let discountAmount = 0;
      if (validatedData.couponCode) {
        try {
          const coupon = await prisma.coupon.findFirst({
            where: {
              code: validatedData.couponCode.toUpperCase(),
              isActive: true,
              validFrom: { lte: new Date() },
              OR: [
                { validTo: null },
                { validTo: { gte: new Date() } }
              ]
            }
          });

          if (coupon && (!coupon.minOrderValue || subtotal >= coupon.minOrderValue)) {
            if (coupon.type === 'PERCENTAGE') {
              discountAmount = (subtotal * coupon.value) / 100;
            } else if (coupon.type === 'FIXED_AMOUNT') {
              discountAmount = coupon.value;
            } else if (coupon.type === 'FREE_SHIPPING') {
              discountAmount = shippingCost;
            }
            
            // Cap discount at order subtotal
            discountAmount = Math.min(discountAmount, subtotal);
          }
        } catch (couponError) {
          console.warn('Error applying coupon:', couponError);
          // Continue without discount
        }
      }

      const total = subtotal + vatAmount + shippingCost - discountAmount;

      // Generate order number
      const orderNumber = generateOrderNumber();

      // Prepare billing address
      const billingAddress = validatedData.sameAsBilling ? 
        validatedData.shippingAddress : 
        (validatedData.billingAddress || validatedData.shippingAddress);

      // Create order
      const orderData = {
        orderNumber,
        userId: validatedData.userId || null,
        email: validatedData.email.toLowerCase().trim(),
        phone: validatedData.phone,
        shippingAddress: {
          firstName: shippingAddress.firstName,
          lastName: shippingAddress.lastName,
          company: shippingAddress.company,
          street1: shippingAddress.street1,
          street2: shippingAddress.street2,
          city: shippingAddress.city,
          state: shippingAddress.state,
          postalCode: shippingAddress.postalCode,
          country: shippingAddress.country,
          phone: shippingAddress.phone,
        },
        billingAddress: {
          firstName: billingAddress.firstName,
          lastName: billingAddress.lastName,
          company: billingAddress.company,
          street1: billingAddress.street1,
          street2: billingAddress.street2,
          city: billingAddress.city,
          state: billingAddress.state,
          postalCode: billingAddress.postalCode,
          country: billingAddress.country,
          phone: billingAddress.phone,
        },
        subtotal,
        taxAmount: vatAmount,
        shippingCost,
        discountAmount,
        total,
        currency: 'EUR',
        status: 'PENDING',
        paymentStatus: 'PENDING',
        fulfillmentStatus: 'PENDING',
        shippingMethod: validatedData.shippingMethod,
        notes: validatedData.orderNotes,
        customerNotes: validatedData.orderNotes,
        items: orderItems,
      };

      const newOrder = await prisma.order.create({
        data: orderData
      });

      // Clear cart items if not guest
      if (validatedData.userId) {
        try {
          await prisma.cartItem.deleteMany({
            where: { userId: validatedData.userId }
          });
        } catch (cartClearError) {
          console.warn('Error clearing cart:', cartClearError);
          // Non-critical error, continue
        }
      } else if (validatedData.sessionId) {
        try {
          await prisma.cartItem.deleteMany({
            where: { sessionId: validatedData.sessionId }
          });
        } catch (cartClearError) {
          console.warn('Error clearing guest cart:', cartClearError);
          // Non-critical error, continue
        }
      }

      // Subscribe to newsletter if requested
      if (validatedData.subscribeNewsletter) {
        try {
          await prisma.newsletterSubscriber.upsert({
            where: { email: validatedData.email.toLowerCase().trim() },
            update: {
              name: `${shippingAddress.firstName} ${shippingAddress.lastName}`,
              isActive: true,
              updatedAt: new Date(),
            },
            create: {
              email: validatedData.email.toLowerCase().trim(),
              name: `${shippingAddress.firstName} ${shippingAddress.lastName}`,
              locale: 'pt',
              source: 'checkout',
              isActive: true,
            }
          });
        } catch (newsletterError) {
          console.warn('Error subscribing to newsletter:', newsletterError);
          // Non-critical error, continue
        }
      }

      // Prepare response
      const orderResponse = {
        id: newOrder.id,
        orderNumber: newOrder.orderNumber,
        status: newOrder.status,
        paymentStatus: newOrder.paymentStatus,
        total: newOrder.total,
        currency: newOrder.currency,
        items: newOrder.items,
        customer: {
          email: newOrder.email,
          phone: newOrder.phone,
        },
        shippingAddress: newOrder.shippingAddress,
        billingAddress: newOrder.billingAddress,
        pricing: {
          subtotal: newOrder.subtotal,
          vatAmount: newOrder.taxAmount,
          shippingCost: newOrder.shippingCost,
          discountAmount: newOrder.discountAmount,
          total: newOrder.total,
        },
        shippingMethod: newOrder.shippingMethod,
        notes: newOrder.notes,
        createdAt: newOrder.createdAt,
      };

      return NextResponse.json(
        {
          success: true,
          data: orderResponse,
          message: 'Pedido criado com sucesso',
          nextSteps: {
            payment: {
              method: validatedData.paymentMethod,
              amount: total,
              currency: 'EUR',
              redirectUrl: `/checkout/payment/${newOrder.id}`,
            }
          }
        },
        { status: 201 }
      );

    } catch (dbError) {
      console.error('Database error creating order:', dbError);
      
      // Fallback response
      return NextResponse.json({
        success: true,
        data: {
          ...mockOrderResponse,
          orderNumber: generateOrderNumber(),
          customer: {
            email: validatedData.email,
            phone: validatedData.phone,
          },
          shippingAddress: validatedData.shippingAddress,
        },
        message: 'Pedido processado com sucesso (será confirmado em breve)',
        fallback: true,
        nextSteps: {
          payment: {
            method: validatedData.paymentMethod,
            amount: mockOrderResponse.total,
            currency: 'EUR',
            redirectUrl: `/checkout/payment/mock_order_123`,
          }
        }
      });
    }

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          message: 'Dados inválidos',
          errors: error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    console.error('Checkout POST error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

// GET method to retrieve shipping and tax estimates
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const country = searchParams.get('country') || 'PT';
    const subtotal = parseFloat(searchParams.get('subtotal') || '0');
    const method = searchParams.get('method') || 'standard';

    if (subtotal <= 0) {
      return NextResponse.json(
        {
          success: false,
          message: 'Subtotal inválido',
        },
        { status: 400 }
      );
    }

    const vatAmount = calculateVAT(subtotal, country);
    const shippingCost = calculateShippingCost(subtotal, method, country);
    const total = subtotal + vatAmount + shippingCost;

    return NextResponse.json({
      success: true,
      data: {
        subtotal,
        vatAmount: Number(vatAmount.toFixed(2)),
        vatRate: VAT_RATES[country] || VAT_RATES.DEFAULT,
        shippingCost: Number(shippingCost.toFixed(2)),
        total: Number(total.toFixed(2)),
        currency: 'EUR',
        country,
        shippingMethod: method,
        freeShippingThreshold: SHIPPING_COSTS[method as keyof typeof SHIPPING_COSTS]?.freeThreshold || SHIPPING_COSTS.standard.freeThreshold,
      },
      message: 'Estimativa calculada com sucesso',
    });

  } catch (error) {
    console.error('Checkout GET error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

// CORS and OPTIONS handler
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-user-id, x-session-id',
    },
  });
}