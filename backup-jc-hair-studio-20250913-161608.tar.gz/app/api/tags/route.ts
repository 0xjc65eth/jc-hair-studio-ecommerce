import { NextRequest, NextResponse } from 'next/server';
import prisma from '../../../lib/prisma';

/**
 * API para gestão de tags
 * GET /api/tags - Lista todas as tags
 * POST /api/tags - Cria uma nova tag
 */

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const includeProductCount = searchParams.get('includeProductCount') === 'true';

    const tags = await prisma.tag.findMany({
      where: {
        isActive: true
      },
      include: includeProductCount ? {
        _count: {
          select: { products: true }
        }
      } : undefined,
      orderBy: [
        { displayOrder: 'asc' },
        { name: 'asc' }
      ]
    });

    return NextResponse.json({
      success: true,
      data: tags,
      count: tags.length,
      message: 'Tags carregadas com sucesso'
    });
  } catch (error) {
    console.error('Get Tags Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    if (!body.name || !body.slug) {
      return NextResponse.json(
        {
          success: false,
          error: 'Campos obrigatórios: name, slug',
        },
        { status: 400 }
      );
    }

    const tag = await prisma.tag.create({
      data: {
        name: body.name,
        slug: body.slug,
        description: body.description || null,
        color: body.color || null,
        displayOrder: body.displayOrder || 0,
        isActive: body.isActive !== false // Default to true
      }
    });

    return NextResponse.json({
      success: true,
      data: tag,
      message: 'Tag criada com sucesso'
    }, { status: 201 });
  } catch (error: any) {
    console.error('Create Tag Error:', error);
    
    if (error.code === 'P2002') {
      return NextResponse.json(
        {
          success: false,
          error: 'Tag com este nome ou slug já existe',
        },
        { status: 409 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}