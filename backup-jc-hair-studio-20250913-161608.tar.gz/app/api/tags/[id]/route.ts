import { NextRequest, NextResponse } from 'next/server';
import prisma from '../../../../lib/prisma';

/**
 * API para gestão individual de tags
 * GET /api/tags/[id] - Busca tag por ID
 * PUT /api/tags/[id] - Atualiza tag
 * DELETE /api/tags/[id] - Remove tag
 */

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    const tag = await prisma.tag.findUnique({
      where: { id },
      include: {
        _count: {
          select: { products: true }
        },
        products: {
          take: 10, // Primeiros 10 produtos com esta tag
          include: {
            product: {
              select: {
                id: true,
                name: true,
                slug: true,
                price: true,
                images: {
                  take: 1,
                  where: { isMain: true }
                }
              }
            }
          }
        }
      }
    });

    if (!tag) {
      return NextResponse.json(
        {
          success: false,
          error: 'Tag não encontrada',
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: tag,
      message: 'Tag encontrada com sucesso'
    });
  } catch (error) {
    console.error('Get Tag Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    const body = await request.json();

    const tag = await prisma.tag.update({
      where: { id },
      data: {
        name: body.name,
        slug: body.slug,
        description: body.description,
        color: body.color,
        displayOrder: body.displayOrder,
        isActive: body.isActive
      }
    });

    return NextResponse.json({
      success: true,
      data: tag,
      message: 'Tag atualizada com sucesso'
    });
  } catch (error: any) {
    console.error('Update Tag Error:', error);
    
    if (error.code === 'P2025') {
      return NextResponse.json(
        {
          success: false,
          error: 'Tag não encontrada',
        },
        { status: 404 }
      );
    }

    if (error.code === 'P2002') {
      return NextResponse.json(
        {
          success: false,
          error: 'Tag com este nome ou slug já existe',
        },
        { status: 409 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    // Check if tag has associated products
    const tagWithProducts = await prisma.tag.findUnique({
      where: { id },
      include: {
        _count: {
          select: { products: true }
        }
      }
    });

    if (!tagWithProducts) {
      return NextResponse.json(
        {
          success: false,
          error: 'Tag não encontrada',
        },
        { status: 404 }
      );
    }

    if (tagWithProducts._count.products > 0) {
      return NextResponse.json(
        {
          success: false,
          error: `Não é possível excluir a tag pois ela está associada a ${tagWithProducts._count.products} produto(s)`,
        },
        { status: 409 }
      );
    }

    await prisma.tag.delete({
      where: { id }
    });

    return NextResponse.json({
      success: true,
      message: 'Tag excluída com sucesso'
    });
  } catch (error: any) {
    console.error('Delete Tag Error:', error);
    
    if (error.code === 'P2025') {
      return NextResponse.json(
        {
          success: false,
          error: 'Tag não encontrada',
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}