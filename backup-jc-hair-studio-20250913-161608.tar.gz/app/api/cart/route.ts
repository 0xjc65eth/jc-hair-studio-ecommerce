import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/mongodb';

// Validation schemas
const CartQuerySchema = z.object({
  sessionId: z.string().optional(),
  userId: z.string().optional(),
});

const AddToCartSchema = z.object({
  productId: z.string().min(1, 'ID do produto é obrigatório'),
  variantId: z.string().optional(),
  quantity: z.number().int().min(1, 'Quantidade deve ser pelo menos 1').max(50, 'Quantidade máxima é 50'),
  selectedOptions: z.record(z.any()).optional(), // Product options selected
});

const UpdateCartSchema = z.object({
  cartItemId: z.string().min(1, 'ID do item do carrinho é obrigatório'),
  quantity: z.number().int().min(0, 'Quantidade não pode ser negativa').max(50, 'Quantidade máxima é 50'),
});

const RemoveFromCartSchema = z.object({
  cartItemId: z.string().min(1, 'ID do item do carrinho é obrigatório'),
});

// Mock cart data for fallback
const mockCartData = {
  items: [
    {
      id: 'cart_item_1',
      productId: 'mock_1',
      variantId: null,
      quantity: 2,
      selectedOptions: {
        cor: 'Preto Natural',
        comprimento: '60cm'
      },
      product: {
        id: 'mock_1',
        name: 'Extensões Brasileiras Premium - 60cm',
        slug: 'extensoes-brasileiras-premium-60cm',
        sku: 'EXT-BR-60-BLK',
        price: 149.99,
        promoPrice: 129.99,
        isOnPromotion: true,
        images: [
          {
            url: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400',
            alt: 'Extensões Brasileiras Premium',
            isMain: true,
          }
        ],
        brand: 'JC Hair Studio',
        hairType: 'STRAIGHT',
        length: 60,
        weight: 100,
        quantity: 25,
        trackQuantity: true,
      },
      unitPrice: 129.99,
      totalPrice: 259.98,
      createdAt: new Date('2024-01-20'),
      updatedAt: new Date('2024-01-20'),
    }
  ],
  summary: {
    itemCount: 2,
    uniqueItemCount: 1,
    subtotal: 259.98,
    taxAmount: 0, // European VAT will be calculated
    shippingCost: 15.99,
    discountAmount: 0,
    total: 275.97,
  },
  appliedCoupons: [],
  availableShipping: [
    {
      id: 'standard',
      name: 'Envio Standard',
      description: 'Entrega em 3-5 dias úteis',
      price: 15.99,
      estimatedDays: '3-5',
      isDefault: true,
    },
    {
      id: 'express',
      name: 'Envio Expresso',
      description: 'Entrega em 1-2 dias úteis',
      price: 29.99,
      estimatedDays: '1-2',
      isDefault: false,
    }
  ]
};

// Helper functions
async function calculateCartTotals(items: any[]) {
  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  
  // European VAT calculation (simplified - should vary by country)
  const vatRate = 0.21; // 21% VAT for Portugal
  const taxAmount = subtotal * vatRate;
  
  // Shipping calculation (simplified)
  const shippingCost = subtotal > 100 ? 0 : 15.99; // Free shipping over 100€
  
  const total = subtotal + taxAmount + shippingCost;
  
  return {
    itemCount,
    uniqueItemCount: items.length,
    subtotal: Number(subtotal.toFixed(2)),
    taxAmount: Number(taxAmount.toFixed(2)),
    shippingCost: Number(shippingCost.toFixed(2)),
    discountAmount: 0, // To be implemented with coupon system
    total: Number(total.toFixed(2)),
  };
}

async function getProductWithPrice(productId: string, variantId?: string) {
  try {
    const product = await prisma.product.findFirst({
      where: {
        id: productId,
        status: 'ACTIVE'
      }
    });
    
    if (!product) return null;
    
    // Get variant if specified
    let variant = null;
    if (variantId) {
      variant = await prisma.productVariant.findFirst({
        where: {
          id: variantId,
          productId: productId,
          isActive: true
        }
      });
    }
    
    // Calculate effective price
    const effectivePrice = variant?.price || 
                          (product.isOnPromotion && product.promoPrice ? product.promoPrice : product.price);
    
    return {
      ...product,
      variant,
      effectivePrice
    };
  } catch (error) {
    console.error('Error fetching product:', error);
    return null;
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId') || undefined;
    const sessionId = searchParams.get('sessionId') || request.headers.get('x-session-id') || undefined;

    if (!userId && !sessionId) {
      return NextResponse.json({
        success: true,
        data: {
          items: [],
          summary: {
            itemCount: 0,
            uniqueItemCount: 0,
            subtotal: 0,
            taxAmount: 0,
            shippingCost: 0,
            discountAmount: 0,
            total: 0,
          },
          appliedCoupons: [],
          availableShipping: mockCartData.availableShipping
        },
        message: 'Carrinho vazio'
      });
    }

    try {
      // Get cart items from database
      const whereClause: any = {};
      
      if (userId) {
        whereClause.userId = userId;
      } else if (sessionId) {
        whereClause.sessionId = sessionId;
        whereClause.userId = null; // Guest cart
      }

      const cartItems = await prisma.cartItem.findMany({
        where: whereClause,
        orderBy: { createdAt: 'desc' }
      });

      // Enrich cart items with product data
      const enrichedItems = await Promise.all(
        cartItems.map(async (item) => {
          const productData = await getProductWithPrice(item.productId, item.variantId || undefined);
          
          if (!productData) {
            // Product no longer exists, should be cleaned up
            return null;
          }

          const unitPrice = productData.effectivePrice;
          const totalPrice = unitPrice * item.quantity;

          return {
            id: item.id,
            productId: item.productId,
            variantId: item.variantId,
            quantity: item.quantity,
            selectedOptions: item.selectedOptions || {},
            product: productData,
            unitPrice,
            totalPrice: Number(totalPrice.toFixed(2)),
            createdAt: item.createdAt,
            updatedAt: item.updatedAt,
          };
        })
      );

      // Filter out null items (products that no longer exist)
      const validItems = enrichedItems.filter(item => item !== null);
      
      // Calculate totals
      const summary = await calculateCartTotals(validItems);

      return NextResponse.json({
        success: true,
        data: {
          items: validItems,
          summary,
          appliedCoupons: [], // To be implemented
          availableShipping: mockCartData.availableShipping
        },
        message: 'Carrinho carregado com sucesso'
      });

    } catch (dbError) {
      console.error('Database error in cart API:', dbError);
      
      // Fallback to mock data
      return NextResponse.json({
        success: true,
        data: {
          ...mockCartData,
          summary: mockCartData.summary,
        },
        message: 'Carrinho carregado com dados de exemplo (banco indisponível)',
        fallback: true,
      });
    }

  } catch (error) {
    console.error('Cart GET error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate request body
    const validatedData = AddToCartSchema.parse(body);
    
    // Get user/session info
    const userId = request.headers.get('x-user-id') || undefined;
    const sessionId = request.headers.get('x-session-id') || body.sessionId;

    if (!userId && !sessionId) {
      return NextResponse.json(
        {
          success: false,
          message: 'Session ID ou User ID é obrigatório',
          error: 'Identificação necessária para adicionar ao carrinho'
        },
        { status: 400 }
      );
    }

    try {
      // Verify product exists and is available
      const productData = await getProductWithPrice(validatedData.productId, validatedData.variantId);
      
      if (!productData) {
        return NextResponse.json(
          {
            success: false,
            message: 'Produto não encontrado',
            error: 'Produto não existe ou não está disponível'
          },
          { status: 404 }
        );
      }

      // Check stock availability
      const availableStock = productData.variant?.quantity || productData.quantity;
      
      if (productData.trackQuantity && validatedData.quantity > availableStock) {
        return NextResponse.json(
          {
            success: false,
            message: 'Quantidade não disponível',
            error: `Apenas ${availableStock} unidades disponíveis`,
            availableQuantity: availableStock
          },
          { status: 400 }
        );
      }

      // Check if item already exists in cart
      const existingItem = await prisma.cartItem.findFirst({
        where: {
          productId: validatedData.productId,
          variantId: validatedData.variantId,
          ...(userId ? { userId } : { sessionId, userId: null })
        }
      });

      let cartItem;
      
      if (existingItem) {
        // Update existing item quantity
        const newQuantity = existingItem.quantity + validatedData.quantity;
        
        if (productData.trackQuantity && newQuantity > availableStock) {
          return NextResponse.json(
            {
              success: false,
              message: 'Quantidade total excede o estoque',
              error: `Máximo ${availableStock} unidades (${existingItem.quantity} já no carrinho)`,
              availableQuantity: availableStock - existingItem.quantity
            },
            { status: 400 }
          );
        }

        cartItem = await prisma.cartItem.update({
          where: { id: existingItem.id },
          data: {
            quantity: newQuantity,
            selectedOptions: validatedData.selectedOptions || existingItem.selectedOptions,
            updatedAt: new Date(),
          }
        });
      } else {
        // Create new cart item
        cartItem = await prisma.cartItem.create({
          data: {
            productId: validatedData.productId,
            variantId: validatedData.variantId,
            quantity: validatedData.quantity,
            selectedOptions: validatedData.selectedOptions,
            userId: userId || null,
            sessionId: sessionId || null,
          }
        });
      }

      // Return enriched cart item
      const unitPrice = productData.effectivePrice;
      const totalPrice = unitPrice * cartItem.quantity;

      const enrichedCartItem = {
        id: cartItem.id,
        productId: cartItem.productId,
        variantId: cartItem.variantId,
        quantity: cartItem.quantity,
        selectedOptions: cartItem.selectedOptions,
        product: {
          id: productData.id,
          name: productData.name,
          slug: productData.slug,
          sku: productData.sku,
          price: productData.price,
          promoPrice: productData.promoPrice,
          isOnPromotion: productData.isOnPromotion,
          images: productData.images,
          brand: productData.brand,
          quantity: productData.quantity,
          trackQuantity: productData.trackQuantity,
        },
        unitPrice,
        totalPrice: Number(totalPrice.toFixed(2)),
        createdAt: cartItem.createdAt,
        updatedAt: cartItem.updatedAt,
      };

      return NextResponse.json(
        {
          success: true,
          data: enrichedCartItem,
          message: existingItem ? 'Quantidade atualizada no carrinho' : 'Produto adicionado ao carrinho',
        },
        { status: existingItem ? 200 : 201 }
      );

    } catch (dbError) {
      console.error('Database error adding to cart:', dbError);
      
      return NextResponse.json(
        {
          success: false,
          message: 'Erro ao adicionar produto ao carrinho',
          error: process.env.NODE_ENV === 'development' ? dbError : undefined,
        },
        { status: 500 }
      );
    }

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          message: 'Dados inválidos',
          errors: error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    console.error('Cart POST error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate request body
    const validatedData = UpdateCartSchema.parse(body);
    
    try {
      // Get cart item
      const cartItem = await prisma.cartItem.findFirst({
        where: { id: validatedData.cartItemId }
      });

      if (!cartItem) {
        return NextResponse.json(
          {
            success: false,
            message: 'Item do carrinho não encontrado',
          },
          { status: 404 }
        );
      }

      // If quantity is 0, remove the item
      if (validatedData.quantity === 0) {
        await prisma.cartItem.delete({
          where: { id: validatedData.cartItemId }
        });

        return NextResponse.json({
          success: true,
          message: 'Item removido do carrinho',
        });
      }

      // Verify product stock
      const productData = await getProductWithPrice(cartItem.productId, cartItem.variantId || undefined);
      
      if (!productData) {
        return NextResponse.json(
          {
            success: false,
            message: 'Produto não encontrado',
          },
          { status: 404 }
        );
      }

      const availableStock = productData.variant?.quantity || productData.quantity;
      
      if (productData.trackQuantity && validatedData.quantity > availableStock) {
        return NextResponse.json(
          {
            success: false,
            message: 'Quantidade não disponível',
            error: `Apenas ${availableStock} unidades disponíveis`,
            availableQuantity: availableStock
          },
          { status: 400 }
        );
      }

      // Update cart item
      const updatedCartItem = await prisma.cartItem.update({
        where: { id: validatedData.cartItemId },
        data: {
          quantity: validatedData.quantity,
          updatedAt: new Date(),
        }
      });

      return NextResponse.json({
        success: true,
        data: updatedCartItem,
        message: 'Quantidade atualizada no carrinho',
      });

    } catch (dbError) {
      console.error('Database error updating cart:', dbError);
      
      return NextResponse.json(
        {
          success: false,
          message: 'Erro ao atualizar carrinho',
          error: process.env.NODE_ENV === 'development' ? dbError : undefined,
        },
        { status: 500 }
      );
    }

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          message: 'Dados inválidos',
          errors: error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    console.error('Cart PUT error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const cartItemId = searchParams.get('cartItemId');
    const userId = searchParams.get('userId') || request.headers.get('x-user-id');
    const sessionId = searchParams.get('sessionId') || request.headers.get('x-session-id');
    const clearAll = searchParams.get('clearAll') === 'true';

    if (clearAll) {
      // Clear entire cart
      if (!userId && !sessionId) {
        return NextResponse.json(
          {
            success: false,
            message: 'Session ID ou User ID é obrigatório',
          },
          { status: 400 }
        );
      }

      try {
        const whereClause: any = {};
        if (userId) {
          whereClause.userId = userId;
        } else if (sessionId) {
          whereClause.sessionId = sessionId;
          whereClause.userId = null;
        }

        await prisma.cartItem.deleteMany({
          where: whereClause
        });

        return NextResponse.json({
          success: true,
          message: 'Carrinho limpo com sucesso',
        });

      } catch (dbError) {
        console.error('Database error clearing cart:', dbError);
        
        return NextResponse.json(
          {
            success: false,
            message: 'Erro ao limpar carrinho',
            error: process.env.NODE_ENV === 'development' ? dbError : undefined,
          },
          { status: 500 }
        );
      }
    } else if (cartItemId) {
      // Remove specific item
      const validatedData = RemoveFromCartSchema.parse({ cartItemId });

      try {
        const cartItem = await prisma.cartItem.findFirst({
          where: { id: validatedData.cartItemId }
        });

        if (!cartItem) {
          return NextResponse.json(
            {
              success: false,
              message: 'Item do carrinho não encontrado',
            },
            { status: 404 }
          );
        }

        await prisma.cartItem.delete({
          where: { id: validatedData.cartItemId }
        });

        return NextResponse.json({
          success: true,
          message: 'Item removido do carrinho',
        });

      } catch (dbError) {
        console.error('Database error removing cart item:', dbError);
        
        return NextResponse.json(
          {
            success: false,
            message: 'Erro ao remover item do carrinho',
            error: process.env.NODE_ENV === 'development' ? dbError : undefined,
          },
          { status: 500 }
        );
      }
    } else {
      return NextResponse.json(
        {
          success: false,
          message: 'cartItemId ou clearAll=true é obrigatório',
        },
        { status: 400 }
      );
    }

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          message: 'Dados inválidos',
          errors: error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    console.error('Cart DELETE error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

// CORS and OPTIONS handler
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-user-id, x-session-id',
    },
  });
}