import { NextRequest, NextResponse } from 'next/server';
import prisma from '../../../lib/prisma';

interface CreateOrderRequest {
  // Customer Information
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  
  // Shipping Address
  address: string;
  address2?: string;
  city: string;
  postalCode: string;
  country: string;
  
  // Cart Items
  items: {
    productId: string;
    variantId?: string;
    quantity: number;
  }[];
  
  // Totals
  subtotal: number;
  taxAmount: number;
  shippingCost: number;
  total: number;
  
  // Payment
  paymentMethod: 'card' | 'paypal' | 'mbway';
  
  // Additional options
  customerNotes?: string;
}

// Generate order number
function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `JC${timestamp.toUpperCase()}${random.toUpperCase()}`;
}

export async function POST(request: NextRequest) {
  try {
    const body: CreateOrderRequest = await request.json();
    
    // Validate required fields
    if (!body.email || !body.firstName || !body.lastName || !body.items?.length) {
      return NextResponse.json(
        {
          success: false,
          error: 'Missing required fields',
        },
        { status: 400 }
      );
    }

    // Start transaction
    const order = await prisma.$transaction(async (tx) => {
      // Create shipping address
      const shippingAddress = await tx.address.create({
        data: {
          userId: 'guest', // For guest checkout, we use a placeholder
          type: 'SHIPPING',
          firstName: body.firstName,
          lastName: body.lastName,
          street1: body.address,
          street2: body.address2 || null,
          city: body.city,
          postalCode: body.postalCode,
          country: body.country,
          phone: body.phone,
          isDefault: false,
          isActive: true,
        },
      });

      // Get product details for order items
      const productIds = body.items.map(item => item.productId);
      const products = await tx.product.findMany({
        where: {
          id: { in: productIds },
          status: 'ACTIVE'
        },
        include: {
          variants: true
        }
      });

      // Validate all products exist and are active
      if (products.length !== productIds.length) {
        throw new Error('Some products are not available');
      }

      // Prepare order items with current prices
      const orderItems = body.items.map(item => {
        const product = products.find(p => p.id === item.productId);
        if (!product) throw new Error(`Product ${item.productId} not found`);

        let price = product.price;
        let sku = product.sku;
        let name = product.name;

        // If variant specified, use variant price and details
        if (item.variantId) {
          const variant = product.variants.find(v => v.id === item.variantId);
          if (!variant) throw new Error(`Variant ${item.variantId} not found`);
          
          price = variant.price || product.price;
          sku = variant.sku;
          name = `${product.name} - ${variant.name}`;
        }

        return {
          productId: item.productId,
          variantId: item.variantId || null,
          name,
          sku,
          price,
          quantity: item.quantity,
        };
      });

      // Create the order
      const newOrder = await tx.order.create({
        data: {
          orderNumber: generateOrderNumber(),
          email: body.email,
          phone: body.phone,
          shippingAddressId: shippingAddress.id,
          subtotal: body.subtotal,
          taxAmount: body.taxAmount,
          shippingCost: body.shippingCost,
          total: body.total,
          currency: 'EUR',
          status: 'PENDING',
          paymentStatus: 'PENDING',
          fulfillmentStatus: 'PENDING',
          customerNotes: body.customerNotes || null,
          items: {
            create: orderItems
          }
        },
        include: {
          items: {
            include: {
              product: true
            }
          },
          shippingAddress: true
        }
      });

      // Create payment record
      await tx.payment.create({
        data: {
          orderId: newOrder.id,
          amount: body.total,
          currency: 'EUR',
          method: body.paymentMethod.toUpperCase() as any,
          status: 'PENDING'
        }
      });

      // Update product inventory (reduce stock)
      for (const item of body.items) {
        const product = products.find(p => p.id === item.productId);
        if (product && product.trackQuantity) {
          await tx.product.update({
            where: { id: item.productId },
            data: {
              quantity: {
                decrement: item.quantity
              }
            }
          });
        }
      }

      return newOrder;
    });

    // TODO: Here you would integrate with actual payment processor
    // For now, we'll simulate payment processing
    
    // Simulate payment success (in real implementation, this would depend on payment gateway response)
    const paymentSuccess = true;
    
    if (paymentSuccess) {
      // Update order status
      await prisma.order.update({
        where: { id: order.id },
        data: {
          status: 'CONFIRMED',
          paymentStatus: 'PAID',
          fulfillmentStatus: 'PROCESSING'
        }
      });

      // Update payment status
      await prisma.payment.updateMany({
        where: { orderId: order.id },
        data: {
          status: 'PAID'
        }
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: paymentSuccess ? 'CONFIRMED' : 'PENDING',
        paymentStatus: paymentSuccess ? 'PAID' : 'PENDING',
        total: order.total
      },
    }, { status: 201 });

  } catch (error: any) {
    console.error('Create Order Error:', error);
    
    // Handle specific errors
    if (error.message.includes('not available') || error.message.includes('not found')) {
      return NextResponse.json(
        {
          success: false,
          error: error.message,
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Failed to create order',
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const orderId = searchParams.get('orderId');
    const orderNumber = searchParams.get('orderNumber');
    const email = searchParams.get('email');

    if (!orderId && !orderNumber && !email) {
      return NextResponse.json(
        {
          success: false,
          error: 'orderId, orderNumber, or email is required',
        },
        { status: 400 }
      );
    }

    let whereClause: any = {};
    
    if (orderId) {
      whereClause.id = orderId;
    } else if (orderNumber) {
      whereClause.orderNumber = orderNumber;
    } else if (email) {
      whereClause.email = email;
    }

    const orders = await prisma.order.findMany({
      where: whereClause,
      include: {
        items: {
          include: {
            product: {
              include: {
                images: true
              }
            }
          }
        },
        shippingAddress: true,
        payments: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    // If looking for specific order by ID or number, return single order
    if (orderId || orderNumber) {
      const order = orders[0];
      if (!order) {
        return NextResponse.json(
          {
            success: false,
            error: 'Order not found',
          },
          { status: 404 }
        );
      }

      return NextResponse.json({
        success: true,
        data: order,
      });
    }

    // Return all orders for email
    return NextResponse.json({
      success: true,
      data: orders,
    });

  } catch (error: any) {
    console.error('Get Orders Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch orders',
      },
      { status: 500 }
    );
  }
}