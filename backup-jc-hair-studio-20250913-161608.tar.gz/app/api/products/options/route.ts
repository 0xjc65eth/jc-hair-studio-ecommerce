import { NextRequest, NextResponse } from 'next/server';
import prisma from '../../../../lib/prisma';

/**
 * API para gestão de opções de produto (variações)
 * GET /api/products/options?productId=xxx - Lista opções de um produto
 * POST /api/products/options - Cria nova opção para um produto
 */

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const productId = searchParams.get('productId');

    if (!productId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Product ID é obrigatório',
        },
        { status: 400 }
      );
    }

    const options = await prisma.productOption.findMany({
      where: { productId },
      include: {
        values: {
          where: { isActive: true },
          orderBy: { displayOrder: 'asc' }
        }
      },
      orderBy: { displayOrder: 'asc' }
    });

    return NextResponse.json({
      success: true,
      data: options,
      count: options.length,
      productId,
      message: 'Opções do produto carregadas com sucesso'
    });
  } catch (error) {
    console.error('Get Product Options Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    if (!body.productId || !body.name || !body.displayName) {
      return NextResponse.json(
        {
          success: false,
          error: 'Campos obrigatórios: productId, name, displayName',
        },
        { status: 400 }
      );
    }

    // Verify product exists
    const product = await prisma.product.findUnique({
      where: { id: body.productId }
    });

    if (!product) {
      return NextResponse.json(
        {
          success: false,
          error: 'Produto não encontrado',
        },
        { status: 404 }
      );
    }

    const option = await prisma.productOption.create({
      data: {
        productId: body.productId,
        name: body.name,
        displayName: body.displayName,
        type: body.type || 'SELECT',
        isRequired: body.isRequired !== false, // Default to true
        displayOrder: body.displayOrder || 0,
        values: body.values ? {
          create: body.values.map((value: any, index: number) => ({
            value: value.value,
            label: value.label || null,
            hexColor: value.hexColor || null,
            priceAdjustment: value.priceAdjustment || 0,
            quantity: value.quantity || 0,
            isActive: value.isActive !== false, // Default to true
            displayOrder: index
          }))
        } : undefined
      },
      include: {
        values: {
          where: { isActive: true },
          orderBy: { displayOrder: 'asc' }
        }
      }
    });

    return NextResponse.json({
      success: true,
      data: option,
      message: 'Opção de produto criada com sucesso'
    }, { status: 201 });
  } catch (error: any) {
    console.error('Create Product Option Error:', error);
    
    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}