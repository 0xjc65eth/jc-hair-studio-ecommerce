import { NextRequest, NextResponse } from 'next/server';
import prisma from '../../../../../lib/prisma';

/**
 * API para gestão individual de opções de produto
 * GET /api/products/options/[id] - Busca opção por ID
 * PUT /api/products/options/[id] - Atualiza opção
 * DELETE /api/products/options/[id] - Remove opção
 */

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    const option = await prisma.productOption.findUnique({
      where: { id },
      include: {
        values: {
          orderBy: { displayOrder: 'asc' }
        },
        product: {
          select: {
            id: true,
            name: true,
            slug: true
          }
        }
      }
    });

    if (!option) {
      return NextResponse.json(
        {
          success: false,
          error: 'Opção não encontrada',
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: option,
      message: 'Opção encontrada com sucesso'
    });
  } catch (error) {
    console.error('Get Product Option Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    const body = await request.json();

    const option = await prisma.productOption.update({
      where: { id },
      data: {
        name: body.name,
        displayName: body.displayName,
        type: body.type,
        isRequired: body.isRequired,
        displayOrder: body.displayOrder,
        ...(body.values && {
          values: {
            deleteMany: {}, // Remove existing values
            create: body.values.map((value: any, index: number) => ({
              value: value.value,
              label: value.label || null,
              hexColor: value.hexColor || null,
              priceAdjustment: value.priceAdjustment || 0,
              quantity: value.quantity || 0,
              isActive: value.isActive !== false,
              displayOrder: index
            }))
          }
        })
      },
      include: {
        values: {
          where: { isActive: true },
          orderBy: { displayOrder: 'asc' }
        }
      }
    });

    return NextResponse.json({
      success: true,
      data: option,
      message: 'Opção atualizada com sucesso'
    });
  } catch (error: any) {
    console.error('Update Product Option Error:', error);
    
    if (error.code === 'P2025') {
      return NextResponse.json(
        {
          success: false,
          error: 'Opção não encontrada',
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    await prisma.productOption.delete({
      where: { id }
    });

    return NextResponse.json({
      success: true,
      message: 'Opção excluída com sucesso'
    });
  } catch (error: any) {
    console.error('Delete Product Option Error:', error);
    
    if (error.code === 'P2025') {
      return NextResponse.json(
        {
          success: false,
          error: 'Opção não encontrada',
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Erro interno do servidor',
      },
      { status: 500 }
    );
  }
}