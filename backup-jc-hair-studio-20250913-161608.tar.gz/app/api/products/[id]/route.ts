import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/mongodb';

// Validation schema for tracking data
const TrackViewSchema = z.object({
  sessionId: z.string().optional(),
  userId: z.string().optional(),
  userAgent: z.string().optional(),
  ip: z.string().optional(),
  referer: z.string().optional(),
});

// Mock data for single product detail
const mockProductDetail = {
  id: 'mock_1',
  name: 'Extensões Brasileiras Premium - 60cm',
  slug: 'extensoes-brasileiras-premium-60cm',
  description: `
    <h3>Extensões de Cabelo Brasileiro Premium</h3>
    <p>Nossas extensões são feitas com 100% cabelo humano brasileiro, conhecido mundialmente pela sua qualidade excepcional e versatilidade.</p>
    
    <h4>Características:</h4>
    <ul>
      <li>100% cabelo humano virgem</li>
      <li>Origem: Brasil</li>
      <li>Comprimento: 60cm</li>
      <li>Textura: Lisa natural</li>
      <li>Cor: Preto natural</li>
      <li>Peso: 100g por pacote</li>
      <li>Durabilidade: 12-18 meses com cuidados adequados</li>
    </ul>
    
    <h4>Cuidados:</h4>
    <p>Para manter a qualidade das extensões, recomendamos:</p>
    <ul>
      <li>Lavar com produtos sem sulfato</li>
      <li>Usar máscara hidratante semanalmente</li>
      <li>Evitar exposição excessiva ao calor</li>
      <li>Pentear suavemente quando seco</li>
    </ul>
  `,
  shortDesc: 'Cabelo brasileiro premium para alongamento com 60cm de comprimento',
  sku: 'EXT-BR-60-BLK',
  barcode: null,
  price: 149.99,
  professionalPrice: 119.99,
  comparePrice: 199.99,
  cost: 75.00,
  isOnPromotion: true,
  promoPrice: 129.99,
  promoStartDate: new Date('2024-01-01'),
  promoEndDate: new Date('2024-12-31'),
  weight: 100,
  length: 60,
  hairType: 'STRAIGHT',
  hairTexture: 'FINE',
  hairColor: 'Preto Natural',
  hairOrigin: 'Brasil',
  brand: 'JC Hair Studio',
  productLine: 'Premium Collection',
  volume: null,
  productType: 'HAIR_EXTENSION',
  trackQuantity: true,
  quantity: 25,
  lowStockAlert: 5,
  status: 'ACTIVE',
  isDigital: false,
  requiresShipping: true,
  metaTitle: 'Extensões Brasileiras Premium 60cm - JC Hair Studio',
  metaDescription: 'Extensões de cabelo brasileiro 100% natural. Qualidade premium, cor preta, 60cm de comprimento.',
  keywords: 'extensões cabelo, cabelo brasileiro, hair extensions, alongamento',
  displayOrder: 1,
  isFeatured: true,
  categoryIds: ['cat_extensions'],
  images: [
    {
      url: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800',
      alt: 'Extensões Brasileiras Premium 60cm - Vista frontal',
      title: 'Vista frontal das extensões',
      displayOrder: 0,
      isMain: true,
    },
    {
      url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800',
      alt: 'Extensões Brasileiras Premium 60cm - Detalhes',
      title: 'Detalhes da textura',
      displayOrder: 1,
      isMain: false,
    },
    {
      url: 'https://images.unsplash.com/photo-1519699047748-de8e457a634e?w=800',
      alt: 'Extensões Brasileiras Premium 60cm - Aplicação',
      title: 'Exemplo de aplicação',
      displayOrder: 2,
      isMain: false,
    }
  ],
  options: [
    {
      id: 'color_option',
      name: 'Cor',
      displayName: 'Escolha a cor',
      type: 'COLOR',
      isRequired: true,
      displayOrder: 0,
      values: [
        {
          id: 'black_natural',
          value: 'Preto Natural',
          label: 'Preto Natural',
          hexColor: '#1a1a1a',
          priceAdjustment: 0,
          quantity: 25,
          isActive: true,
          displayOrder: 0,
        },
        {
          id: 'brown_chocolate',
          value: 'Castanho Chocolate',
          label: 'Castanho Chocolate',
          hexColor: '#3e2723',
          priceAdjustment: 0,
          quantity: 15,
          isActive: true,
          displayOrder: 1,
        },
        {
          id: 'brown_honey',
          value: 'Castanho Mel',
          label: 'Castanho Mel',
          hexColor: '#8d6e63',
          priceAdjustment: 5,
          quantity: 10,
          isActive: true,
          displayOrder: 2,
        }
      ],
    },
    {
      id: 'length_option',
      name: 'Comprimento',
      displayName: 'Escolha o comprimento',
      type: 'SELECT',
      isRequired: true,
      displayOrder: 1,
      values: [
        {
          id: 'length_40',
          value: '40cm',
          label: '40cm',
          priceAdjustment: -20,
          quantity: 30,
          isActive: true,
          displayOrder: 0,
        },
        {
          id: 'length_50',
          value: '50cm',
          label: '50cm',
          priceAdjustment: -10,
          quantity: 28,
          isActive: true,
          displayOrder: 1,
        },
        {
          id: 'length_60',
          value: '60cm',
          label: '60cm',
          priceAdjustment: 0,
          quantity: 25,
          isActive: true,
          displayOrder: 2,
        },
        {
          id: 'length_70',
          value: '70cm',
          label: '70cm',
          priceAdjustment: 15,
          quantity: 20,
          isActive: true,
          displayOrder: 3,
        }
      ],
    }
  ],
  categories: [
    {
      id: 'cat_extensions',
      name: 'Extensões de Cabelo',
      slug: 'extensoes-cabelo',
      description: 'Extensões de cabelo natural e sintético',
    }
  ],
  reviews: [
    {
      id: 'review_1',
      userId: 'user_1',
      userName: 'Maria Silva',
      userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
      rating: 5,
      title: 'Produto excepcional!',
      content: 'Comprei essas extensões há 6 meses e ainda estão perfeitas. A qualidade do cabelo brasileiro é realmente superior.',
      isVerified: true,
      helpfulCount: 12,
      createdAt: new Date('2024-01-10'),
      updatedAt: new Date('2024-01-10'),
    },
    {
      id: 'review_2',
      userId: 'user_2',
      userName: 'Ana Costa',
      userAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100',
      rating: 5,
      title: 'Recomendo muito!',
      content: 'Textura perfeita, cor exatamente como nas fotos. O atendimento da JC Hair Studio também é excelente.',
      isVerified: true,
      helpfulCount: 8,
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-01-15'),
    },
    {
      id: 'review_3',
      userId: 'user_3',
      userName: 'Sofia Mendes',
      userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100',
      rating: 4,
      title: 'Boa qualidade',
      content: 'Extensões de boa qualidade, chegaram rapidamente. Apenas o preço que poderia ser um pouco melhor.',
      isVerified: false,
      helpfulCount: 5,
      createdAt: new Date('2024-01-20'),
      updatedAt: new Date('2024-01-20'),
    }
  ],
  relatedProducts: [
    {
      id: 'related_1',
      name: 'Extensões Brasileiras Cacheadas - 55cm',
      slug: 'extensoes-brasileiras-cacheadas-55cm',
      price: 139.99,
      comparePrice: 179.99,
      images: [
        {
          url: 'https://images.unsplash.com/photo-1564485377539-4af72d1335f7?w=400',
          alt: 'Extensões Cacheadas',
          isMain: true,
        }
      ],
      isFeatured: true,
      rating: 4.8,
      reviewCount: 23,
    },
    {
      id: 'related_2',
      name: 'Kit Manutenção Extensões Premium',
      slug: 'kit-manutencao-extensoes-premium',
      price: 89.99,
      comparePrice: 119.99,
      images: [
        {
          url: 'https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=400',
          alt: 'Kit Manutenção',
          isMain: true,
        }
      ],
      isFeatured: false,
      rating: 4.9,
      reviewCount: 15,
    }
  ],
  rating: {
    average: 4.7,
    count: 28,
    distribution: {
      5: 18,
      4: 7,
      3: 2,
      2: 1,
      1: 0,
    }
  },
  createdAt: new Date('2024-01-15'),
  updatedAt: new Date('2024-01-20'),
  publishedAt: new Date('2024-01-16'),
  viewCount: 1247,
};

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    
    // Get tracking parameters
    const trackingData = {
      sessionId: searchParams.get('sessionId') || undefined,
      userId: searchParams.get('userId') || undefined,
      userAgent: request.headers.get('user-agent') || undefined,
      ip: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || undefined,
      referer: request.headers.get('referer') || undefined,
    };

    try {
      // Try to get product from database
      const product = await prisma.product.findFirst({
        where: {
          OR: [
            { id: id },
            { slug: id },
          ],
          status: 'ACTIVE'
        },
      });

      if (!product) {
        // Check if it's our mock ID
        if (id === 'mock_1' || id === 'extensoes-brasileiras-premium-60cm') {
          // Track view for mock product (in a real app, you'd still want to track)
          try {
            await prisma.productView.create({
              data: {
                productId: 'mock_1',
                userId: trackingData.userId || null,
                sessionId: trackingData.sessionId || 'anonymous_session',
                createdAt: new Date(),
              },
            });
          } catch (trackError) {
            console.warn('Could not track product view:', trackError);
          }

          return NextResponse.json({
            success: true,
            data: {
              product: mockProductDetail,
              relatedProducts: mockProductDetail.relatedProducts,
              reviews: {
                items: mockProductDetail.reviews,
                rating: mockProductDetail.rating,
                pagination: {
                  current: 1,
                  total: 1,
                  count: mockProductDetail.reviews.length,
                  hasNext: false,
                  hasPrev: false,
                  limit: 10,
                }
              }
            },
            message: 'Produto carregado com dados de exemplo',
            fallback: true,
          });
        }

        return NextResponse.json(
          {
            success: false,
            message: 'Produto não encontrado',
          },
          { status: 404 }
        );
      }

      // Track product view in database
      try {
        await prisma.productView.create({
          data: {
            productId: product.id,
            userId: trackingData.userId || null,
            sessionId: trackingData.sessionId || 'anonymous_session',
          },
        });
      } catch (trackError) {
        console.warn('Could not track product view:', trackError);
      }

      // Get related products (same category or similar attributes)
      const relatedProducts = await prisma.product.findMany({
        where: {
          AND: [
            { id: { not: product.id } },
            { status: 'ACTIVE' },
            {
              OR: [
                { productType: product.productType },
                { hairType: product.hairType },
                { brand: product.brand },
              ]
            }
          ]
        },
        take: 4,
        orderBy: [
          { isFeatured: 'desc' },
          { createdAt: 'desc' }
        ],
      });

      // Get reviews for this product
      const reviews = await prisma.review.findMany({
        where: {
          productId: product.id,
          isPublished: true,
        },
        take: 10,
        orderBy: [
          { helpfulCount: 'desc' },
          { createdAt: 'desc' }
        ],
      });

      // Calculate rating statistics
      const ratingStats = reviews.reduce((acc, review) => {
        acc.total += review.rating;
        acc.count++;
        acc.distribution[review.rating as keyof typeof acc.distribution]++;
        return acc;
      }, {
        total: 0,
        count: 0,
        distribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 }
      });

      const rating = {
        average: ratingStats.count > 0 ? Number((ratingStats.total / ratingStats.count).toFixed(1)) : 0,
        count: ratingStats.count,
        distribution: ratingStats.distribution,
      };

      return NextResponse.json({
        success: true,
        data: {
          product: {
            ...product,
            viewCount: await prisma.productView.count({
              where: { productId: product.id }
            })
          },
          relatedProducts,
          reviews: {
            items: reviews,
            rating,
            pagination: {
              current: 1,
              total: Math.ceil(reviews.length / 10),
              count: reviews.length,
              hasNext: false,
              hasPrev: false,
              limit: 10,
            }
          }
        },
        message: 'Produto carregado com sucesso',
      });

    } catch (dbError) {
      console.error('Database error in product detail API:', dbError);
      
      // Fallback to mock data
      if (id === 'mock_1' || id === 'extensoes-brasileiras-premium-60cm') {
        return NextResponse.json({
          success: true,
          data: {
            product: mockProductDetail,
            relatedProducts: mockProductDetail.relatedProducts,
            reviews: {
              items: mockProductDetail.reviews,
              rating: mockProductDetail.rating,
              pagination: {
                current: 1,
                total: 1,
                count: mockProductDetail.reviews.length,
                hasNext: false,
                hasPrev: false,
                limit: 10,
              }
            }
          },
          message: 'Produto carregado com dados de exemplo (banco indisponível)',
          fallback: true,
        });
      }

      return NextResponse.json(
        {
          success: false,
          message: 'Erro ao carregar produto',
          error: process.env.NODE_ENV === 'development' ? dbError : undefined,
        },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Product detail GET error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

// POST method for tracking additional analytics or interactions
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const validatedData = TrackViewSchema.parse(body);
    
    try {
      // Verify product exists
      const product = await prisma.product.findFirst({
        where: {
          OR: [
            { id: id },
            { slug: id },
          ]
        }
      });

      if (!product) {
        return NextResponse.json(
          {
            success: false,
            message: 'Produto não encontrado para tracking',
          },
          { status: 404 }
        );
      }

      // Track additional interaction (view, click, etc.)
      await prisma.productView.create({
        data: {
          productId: product.id,
          userId: validatedData.userId || null,
          sessionId: validatedData.sessionId || 'anonymous_session',
        },
      });

      return NextResponse.json({
        success: true,
        message: 'Interação rastreada com sucesso',
      });

    } catch (dbError) {
      console.error('Database error tracking product interaction:', dbError);
      
      return NextResponse.json({
        success: true,
        message: 'Tracking processado (banco indisponível)',
        fallback: true,
      });
    }

  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          success: false,
          message: 'Dados de tracking inválidos',
          errors: error.flatten().fieldErrors,
        },
        { status: 400 }
      );
    }

    console.error('Product tracking POST error:', error);
    
    return NextResponse.json(
      {
        success: false,
        message: 'Erro interno do servidor',
        error: process.env.NODE_ENV === 'development' ? error : undefined,
      },
      { status: 500 }
    );
  }
}

// CORS and OPTIONS handler
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}