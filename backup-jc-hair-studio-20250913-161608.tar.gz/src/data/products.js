export const products = [
  // PROGRESSIVAS & ALISAMENTOS
  {
    id: 'cadiveu_kit_001',
    nome: 'Kit Cadiveu Plástica dos Fios',
    marca: 'Cadiveu',
    categoria: 'Produtos',
    subcategoria: 'Progressivas com Formol',
    descricao: 'Kit completo para alisamento profissional com resultados duradouros e brilho intenso',
    preco_brl: 468.90,
    preco_eur: 140.67, // R$ 468.90 × 0.20 × 1.5
    imagens: [
      '/images/products/cadiveu/cadiveu-1.png',
      '/images/products/cadiveu/cadiveu-2.png',
      '/images/products/cadiveu/cadiveu-3.png',
      '/images/products/cadiveu/cadiveu-4.png',
      '/images/products/cadiveu/cadiveu-5.png',
      '/images/products/cadiveu/cadiveu-6.png'
    ],
    destaque: true,
    badge: 'BEST SELLER',
    estoque: true
  },
  {
    id: 'forever_liss_btx_001',
    nome: 'Forever Liss Botox Capilar',
    marca: 'Forever Liss',
    categoria: 'Produtos',
    subcategoria: 'BTX/Botox Capilar',
    descricao: 'Botox capilar para reconstrução e hidratação profunda dos fios',
    preco_brl: 132.90,
    preco_eur: 39.87, // R$ 132.90 × 0.20 × 1.5
    imagens: [
      '/images/products/forever-liss/forever-liss-1.png',
      '/images/products/forever-liss/forever-liss-2.png',
      '/images/products/forever-liss/forever-liss-3.png',
      '/images/products/forever-liss/forever-liss-4.png'
    ],
    destaque: true,
    badge: 'PROMOÇÃO',
    estoque: true
  },
  {
    id: 'g_hair_001',
    nome: 'G Hair Progressiva Alemã',
    marca: 'G Hair',
    categoria: 'Produtos',
    subcategoria: 'Progressivas com Formol',
    descricao: 'Progressiva alemã com tecnologia avançada para alisamento perfeito',
    preco_brl: 285.50,
    preco_eur: 85.65, // R$ 285.50 × 0.20 × 1.5
    imagens: [
      '/images/products/g-hair/g-hair-1.png',
      '/images/products/g-hair/g-hair-2.png',
      '/images/products/g-hair/g-hair-3.png',
      '/images/products/g-hair/g-hair-4.png',
      '/images/products/g-hair/g-hair-5.png',
      '/images/products/g-hair/g-hair-6.png'
    ],
    destaque: true,
    badge: 'EXCLUSIVO',
    estoque: true
  },
  {
    id: 'honma_tokyo_001',
    nome: 'Honma Tokyo H-Brush',
    marca: 'Honma Tokyo',
    categoria: 'Produtos',
    subcategoria: 'Progressivas Premium',
    descricao: 'Tratamento premium japonês para alisamento e reconstrução capilar',
    preco_brl: 650.00,
    preco_eur: 195.00, // R$ 650.00 × 0.20 × 1.5
    imagens: [
      '/images/products/honma-tokyo/honma-1.png',
      '/images/products/honma-tokyo/honma-2.png',
      '/images/products/honma-tokyo/honma-3.png',
      '/images/products/honma-tokyo/honma-4.png'
    ],
    destaque: true,
    badge: 'PREMIUM',
    estoque: true
  },
  {
    id: 'vogue_progressiva_001',
    nome: 'Vogue Progressiva Professional',
    marca: 'Vogue',
    categoria: 'Produtos',
    subcategoria: 'Progressivas com Formol',
    descricao: 'Progressiva profissional com tecnologia avançada para alisamento duradouro',
    preco_brl: 198.50,
    preco_eur: 59.55, // R$ 198.50 × 0.20 × 1.5
    imagens: [
      '/images/products/vogue/vogue-1.png',
      '/images/products/vogue/vogue-2.png',
      '/images/products/vogue/vogue-3.png',
      '/images/products/vogue/vogue-4.png'
    ],
    destaque: false,
    badge: 'NOVO',
    estoque: true
  },
  {
    id: 'truss_professional_001',
    nome: 'Truss Professional Kit',
    marca: 'Truss',
    categoria: 'Produtos',
    subcategoria: 'Linha Profissional',
    descricao: 'Kit profissional completo para tratamentos capilares avançados',
    preco_brl: 320.00,
    preco_eur: 96.00,
    imagens: [
      '/images/products/truss/truss-1.png',
      '/images/products/truss/truss-2.png',
      '/images/products/truss/truss-3.png',
      '/images/products/truss/truss-4.png',
      '/images/products/truss/truss-5.png',
      '/images/products/truss/truss-6.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'felps_professional_001',
    nome: 'Felps Professional Omega Zero',
    marca: 'Felps',
    categoria: 'Produtos',
    subcategoria: 'Progressivas sem Formol',
    descricao: 'Progressiva sem formol com óleo de argan para alisamento natural',
    preco_brl: 245.90,
    preco_eur: 73.77,
    imagens: [
      '/images/products/felps/felps-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'felps_sos_001',
    nome: 'Felps S.O.S Reconstrução',
    marca: 'Felps',
    categoria: 'Produtos',
    subcategoria: 'Reconstrução',
    descricao: 'Tratamento intensivo para reconstrução de cabelos danificados',
    preco_brl: 89.90,
    preco_eur: 26.97,
    imagens: [
      '/images/products/felps/felps-sos-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'zap_all_time_001',
    nome: 'Zap All Time Tratamento',
    marca: 'Zap',
    categoria: 'Produtos',
    subcategoria: 'Tratamentos Especiais',
    descricao: 'Tratamento especial para cabelos crespos e cacheados',
    preco_brl: 156.00,
    preco_eur: 46.80,
    imagens: [
      '/images/products/zap/zap-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'inoar_btx_001',
    nome: 'Inoar BTX Máscara Capilar',
    marca: 'Inoar',
    categoria: 'Produtos',
    subcategoria: 'BTX/Botox Capilar',
    descricao: 'Máscara de botox capilar para hidratação e reconstrução intensa',
    preco_brl: 178.50,
    preco_eur: 53.55,
    imagens: [
      '/images/products/inoar/inoar-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'maria_escandalosa_001',
    nome: 'Maria Escandalosa 1K',
    marca: 'Maria Escandalosa',
    categoria: 'Produtos',
    subcategoria: 'Nutrição',
    descricao: 'Máscara nutritiva para cabelos secos e ressecados',
    preco_brl: 67.90,
    preco_eur: 20.37,
    imagens: [
      '/images/products/maria-escandalosa/maria-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'troia_hair_001',
    nome: 'Troia Hair Hidratação Profunda',
    marca: 'Troia Hair',
    categoria: 'Produtos',
    subcategoria: 'Hidratação Profunda',
    descricao: 'Tratamento hidratante intensivo para cabelos ressecados',
    preco_brl: 134.90,
    preco_eur: 40.47,
    imagens: [
      '/images/products/troia/troia-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'salvatore_blue_001',
    nome: 'Salvatore Blue Matizador',
    marca: 'Salvatore',
    categoria: 'Produtos',
    subcategoria: 'Matizadores',
    descricao: 'Matizador azul para neutralizar tons amarelados em cabelos loiros',
    preco_brl: 45.90,
    preco_eur: 13.77,
    imagens: [
      '/images/products/salvatore/salvatore-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'karssel_colageno_001',
    nome: 'Karssel Colágeno Reconstrutor',
    marca: 'Karssel',
    categoria: 'Produtos',
    subcategoria: 'Reconstrução',
    descricao: 'Ampola de colágeno para reconstrução capilar profunda',
    preco_brl: 89.90,
    preco_eur: 26.97,
    imagens: [
      '/images/products/karssel/karssel-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'bioextratus_cronograma_001',
    nome: 'Bio Extratus Cronograma Capilar',
    marca: 'Bio Extratus',
    categoria: 'Produtos',
    subcategoria: 'Cronograma Capilar',
    descricao: 'Kit cronograma capilar completo com 3 etapas',
    preco_brl: 156.90,
    preco_eur: 47.07,
    imagens: [
      '/images/products/bioextratus/cronograma-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'bioextratus_jaborandi_001',
    nome: 'Bio Extratus Jaborandi Antiqueda',
    marca: 'Bio Extratus',
    categoria: 'Produtos',
    subcategoria: 'Antiqueda',
    descricao: 'Shampoo e condicionador antiqueda com extrato de jaborandi',
    preco_brl: 67.90,
    preco_eur: 20.37,
    imagens: [
      '/images/products/bioextratus/jaborandi-1.png'
    ],
    destaque: false,
    estoque: true
  },
  {
    id: 'forever_liss_cauterizacao_001',
    nome: 'Forever Liss Cauterização',
    marca: 'Forever Liss',
    categoria: 'Produtos',
    subcategoria: 'Cauterização',
    descricao: 'Tratamento de cauterização para reparação de fios danificados',
    preco_brl: 98.90,
    preco_eur: 29.67,
    imagens: [
      '/images/products/forever-liss/cauterizacao-1.png'
    ],
    destaque: false,
    estoque: true
  },

  // MAQUIAGEM - CUIDADOS & BELEZA
  {
    id: 'mari_maria_base_001',
    nome: 'Mari Maria Base Cover Up Matte',
    marca: 'Mari Maria',
    categoria: 'Cuidados & Beleza',
    subcategoria: 'Bases',
    descricao: 'Base líquida de alta cobertura com acabamento matte e longa duração',
    preco_brl: 79.90,
    preco_eur: 23.97, // R$ 79.90 × 0.20 × 1.5
    imagens: [
      '/images/products/mari-maria/mari-maria-1.png',
      '/images/products/mari-maria/mari-maria-2.png',
      '/images/products/mari-maria/mari-maria-3.png'
    ],
    destaque: true,
    badge: 'EXCLUSIVO',
    estoque: true
  },
  {
    id: 'boca_rosa_base_001',
    nome: 'Boca Rosa Beauty Stick Pele Multifuncional',
    marca: 'Boca Rosa Beauty',
    categoria: 'Cuidados & Beleza',
    subcategoria: 'Bases',
    descricao: 'Stick multifuncional 3 em 1: base, contour e corretor. Disponível em 50 tonalidades para todos os tipos de pele.',
    preco_brl: 89.90,
    preco_eur: 26.97,
    imagens: [
      '/images/products/boca-rosa/base-1.png',
      '/images/products/boca-rosa/base-2.png',
      '/images/products/boca-rosa/base-3.png',
      '/images/products/boca-rosa/base-4.png'
    ],
    destaque: true,
    badge: 'MULTIFUNCIONAL',
    estoque: true,
    tons: ['BR01', 'BR02', 'BR03', 'BR04', 'BR05', 'BR06', 'BR07', 'BR08', 'BR09', 'BR10',
           'BR11', 'BR12', 'BR13', 'BR14', 'BR15', 'BR16', 'BR17', 'BR18', 'BR19', 'BR20',
           'BR21', 'BR22', 'BR23', 'BR24', 'BR25', 'BR26', 'BR27', 'BR28', 'BR29', 'BR30',
           'BR31', 'BR32', 'BR33', 'BR34', 'BR35', 'BR36', 'BR37', 'BR38', 'BR39', 'BR40',
           'BR41', 'BR42', 'BR43', 'BR44', 'BR45', 'BR46', 'BR47', 'BR48', 'BR49', 'BR50']
  }
];

export const categories = {
  'Produtos': {
    'Progressivas com Formol': ['cadiveu_kit_001', 'g_hair_001', 'vogue_progressiva_001'],
    'Progressivas sem Formol': ['felps_professional_001'],
    'Progressivas Premium': ['honma_tokyo_001'],
    'BTX/Botox Capilar': ['forever_liss_btx_001', 'inoar_btx_001'],
    'Reconstrução': ['felps_sos_001', 'karssel_colageno_001'],
    'Hidratação Profunda': ['troia_hair_001'],
    'Nutrição': ['maria_escandalosa_001'],
    'Cauterização': ['forever_liss_cauterizacao_001'],
    'Cronograma Capilar': ['bioextratus_cronograma_001'],
    'Antiqueda': ['bioextratus_jaborandi_001'],
    'Matizadores': ['salvatore_blue_001'],
    'Tratamentos Especiais': ['zap_all_time_001'],
    'Linha Profissional': ['truss_professional_001']
  },
  'Cuidados & Beleza': {
    'Bases': ['mari_maria_base_001', 'boca_rosa_base_001']
  }
};

export const featuredProducts = [
  'cadiveu_kit_001',
  'forever_liss_btx_001', 
  'g_hair_001',
  'mari_maria_base_001',
  'honma_tokyo_001'
];